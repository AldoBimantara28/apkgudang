package com.tugas.aplikasimonitoringgudang.ui.supplier;

import android.app.Activity;

public class SupplierInputFragment extends Activity {
}
